# LGVM-Task-1
LetsGrowMore Virtual Internship Program 
Web Development Intern

A To-Do-List program using HTML, CSS, JavaScript
